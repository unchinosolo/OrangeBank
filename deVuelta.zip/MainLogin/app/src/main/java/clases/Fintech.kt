package clases

import Interfaces.AutenticacionUsuario
import android.widget.Toast
import excepciones.UsuarioExistente
import repositorios.CuentaRepo
import repositorios.UsuarioRepo

object Fintech:AutenticacionUsuario {

    val listaUsuario = UsuarioRepo.usuarios
    val listaCuentas = CuentaRepo.cuentas

    // INICIO DE SESION - METODOS

    fun buscarCuentaXUsuario (usuario: String):Cuentas?{

        var cuentaEncontrada: Cuentas? = null

       for (cuenta in listaCuentas){
           if (cuenta.usuario.equals(usuario)){
               cuentaEncontrada = cuenta
               break
           }
       }
        return cuentaEncontrada!!
    }

    //  IMPLEMENTACION A INTERFACES

    override fun nickValidation(nickname: String): Boolean {
        return super.nickValidation(nickname)
    }

    override fun passValidation(password: String): Boolean {
        return super.passValidation(password)
    }

}
package clases

data class Cuentas(
    val codigoCuenta: Int,
    val usuario: String,
    val nombre: String,
    val apellido: String,
    var dineroEnCuenta: Double,
    val fechaAlta: String,
    var cantidadBitcoins: Double
)


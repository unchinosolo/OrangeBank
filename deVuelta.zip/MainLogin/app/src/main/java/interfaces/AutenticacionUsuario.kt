package Interfaces

import clases.Cuentas
import repositorios.UsuarioRepo

interface AutenticacionUsuario {

    //METODOS A IMPLEMENTAR

    fun nickValidation(nickname: String): Boolean {
        var nickCorrecto = false;
        for (cuenta in UsuarioRepo.usuarios) {
            if (cuenta.usuario == nickname) {
                nickCorrecto = true;
            }
        }
        return nickCorrecto
    }

    fun passValidation(password: String): Boolean{
        var passValida = false;
        for (cuenta in UsuarioRepo.usuarios) {
            if (cuenta.password == password) {
                passValida = true;
            }
        }
        return passValida
    }
}
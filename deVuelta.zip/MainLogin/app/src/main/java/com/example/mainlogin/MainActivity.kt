package com.example.mainlogin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import clases.Fintech
import com.example.mainlogin.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding: ActivityMainBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)



        val usuario = binding.tvUsuario.toString()
        val password = binding.tvPassword.toString()

        binding.btnIngresar.setOnClickListener {

            if (Fintech.nickValidation(usuario) && Fintech.passValidation(password)){
                Fintech.buscarCuentaXUsuario(usuario)
                Toast.makeText(this, "funciona",Toast.LENGTH_LONG).show()
            }else{
                Toast.makeText(this,"no anda amigo", Toast.LENGTH_LONG).show()
            }

        }

    }
}
package com.example.mainlogin

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import dataClass.Cuentas
import entidades.Fintech
import com.example.mainlogin.databinding.ActivityMainBinding
import fragments.registroFragment

class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding: ActivityMainBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)




        binding.tvRegistrarse.setOnClickListener {
            /*val myFragment = registroFragment()
            val fragment: Fragment? =

                supportFragmentManager.findFragmentByTag(registroFragment::class.java.simpleName)

            if (fragment !is registroFragment) {
                supportFragmentManager.beginTransaction()
                    .add(
                        R.id.registro_fragment,
                        myFragment,
                        registroFragment::class.java.simpleName
                    )
                    .commit()*/

            val registro : Intent = Intent(this,registerActivity::class.java)
            startActivity(registro)


            }



            binding.btnIngresar.setOnClickListener {
                val usuario = binding.tvUsuario.text.toString()
                val password = binding.tvPassword.text.toString()
                var codigoDeCuenta: Int = 0
                var cuentaEncontrada: Cuentas? = null

                if (Fintech.nickValidation(usuario) == true && Fintech.passValidation(password) == true) {

                    codigoDeCuenta = Fintech.buscarCodigoDeCuentaEnRepositorioUsuario(usuario)
                    cuentaEncontrada = Fintech.buscarCuentaEnRepositorioCuenta(codigoDeCuenta)

                    val perfil: Intent = Intent(this, PerfilActivity::class.java)
                    startActivity(perfil)

                    intent.putExtra("codigo", cuentaEncontrada!!.codigoCuenta)

                    Toast.makeText(this, "funciona", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "no anda amigo", Toast.LENGTH_LONG).show()
                }

            }

        }
    }

package dataClass

data class Usuario(val  usuario: String, val password: String, val codigo: Int){


}

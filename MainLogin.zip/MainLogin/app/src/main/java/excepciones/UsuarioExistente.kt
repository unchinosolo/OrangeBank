package excepciones

class UsuarioExistente(message: String?) : Throwable(message) {
}
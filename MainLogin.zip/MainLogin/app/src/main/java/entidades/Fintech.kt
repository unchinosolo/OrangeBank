package entidades

import Interfaces.AutenticacionUsuario
import dataClass.Cuentas
import repositorios.CuentaRepo
import repositorios.UsuarioRepo

object Fintech:AutenticacionUsuario {

    val listaUsuario = UsuarioRepo.usuarios
    val listaCuentas = CuentaRepo.cuentas

    // INICIO DE SESION - METODOS
    // Buscamos en la listaDeUsario que tenga el mismo codigo para vincular Usuario y Cuenta

    fun buscarCodigoDeCuentaEnRepositorioUsuario(usuario: String): Int{

        var codigoDeCuenta = 0
        for(usario in listaUsuario){
            if(usario.usuario.equals(usuario)){
                codigoDeCuenta = usario.codigo
                break
            }
        }
        return codigoDeCuenta
    }

    //Buscamos un codigo de cuenta en la listaDeCuenta

    fun buscarCuentaEnRepositorioCuenta(codigoDeCuentas: Int): Cuentas?{

        var cuentaEncontrada: Cuentas? = null

        for(cuenta in listaCuentas){
            if(cuenta.codigoCuenta == codigoDeCuentas){
                cuentaEncontrada = cuenta
                break
            }
        }
        return cuentaEncontrada!!
    }


    //  IMPLEMENTACION A INTERFACES

    override fun nickValidation(nickname: String): Boolean {
        return super.nickValidation(nickname)
    }

    override fun passValidation(password: String): Boolean {
        return super.passValidation(password)
    }
}